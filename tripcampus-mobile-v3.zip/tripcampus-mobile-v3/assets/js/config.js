/* Fill these in before launch. Leave empty to keep tracking off. */
window.TC_CONFIG = {
  whatsapp: '918943299434',   // number that receives WhatsApp enquiries
  ga4: '',                    // Google Analytics 4 measurement ID, e.g. 'G-XXXXXXX'
  metaPixel: ''               // Meta (Facebook/Instagram) Pixel ID, e.g. '1234567890'
};
